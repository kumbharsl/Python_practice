from demo import Bill_App 

if __name__=="__main__":
    app=Bill_App()