from tkinter  import *
from tkinter import messagebox
from billing import Bill_App 

root =Tk()
root.title('Billing Software')
root.geometry( '1000x500+100+50' )
root.configure(bg= 'white')

img  = PhotoImage(file='new1.png')
Label(root, image=img,bg='white',width=1280,height=720).place(x=0,y=0)
root.mainloop()